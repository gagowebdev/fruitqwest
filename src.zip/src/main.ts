import 'dotenv/config'; // ✅ Добавлено
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // Разрешаем CORS
  app.enableCors({
    origin: 'http://localhost:5173', // Указываем адрес фронтенда
    credentials: true, // Разрешаем передачу cookies и заголовков авторизации
    allowedHeaders: 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
    methods: 'GET, POST, PATCH, DELETE, OPTIONS',
  });
  await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
